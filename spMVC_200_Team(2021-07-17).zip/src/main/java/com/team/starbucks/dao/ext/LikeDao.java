package com.team.starbucks.dao.ext;

import com.team.starbucks.dao.GenericDao;

public interface LikeDao extends GenericDao {
/*	<좋아요기능>
 * 
 * 1. ID기준으로 체크
 * 2. 해당게시물에 좋아요 누른적이 없다면, 누를수있게
 * 3. 누른적이 있다면 못누르게함
 * 
 */
	
}


