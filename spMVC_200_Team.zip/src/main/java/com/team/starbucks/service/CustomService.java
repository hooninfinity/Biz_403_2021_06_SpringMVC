package com.team.starbucks.service;

import java.util.List;

import com.team.starbucks.model.CategoryDTO;

public interface CustomService {

	public List<CategoryDTO> selectAll();
	
	public List<CategoryDTO> base1();
	
	public List<CategoryDTO> base2();
	
	
}
