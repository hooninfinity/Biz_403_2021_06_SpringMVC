package com.team.starbucks.dao.ext;

import com.team.starbucks.dao.GenericDao;
import com.team.starbucks.model.BoardDTO;

public interface BoardDao extends GenericDao<BoardDTO,String>{

}
