package com.team.starbucks.dao.ext;

import com.team.starbucks.dao.GenericDao;
import com.team.starbucks.model.CategoryDTO;

public interface CategoryDao extends GenericDao<CategoryDTO,String>{

}
