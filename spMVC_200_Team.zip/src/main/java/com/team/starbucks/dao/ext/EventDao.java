package com.team.starbucks.dao.ext;

import com.team.starbucks.dao.GenericDao;
import com.team.starbucks.model.EventVO;

public interface EventDao extends GenericDao<EventVO,String>{

}
