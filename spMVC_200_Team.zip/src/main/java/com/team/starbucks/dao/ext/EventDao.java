package com.team.starbucks.dao.ext;

import com.team.starbucks.dao.GenericDao;
import com.team.starbucks.model.EventDTO;

public interface EventDao extends GenericDao<EventDTO,String>{

}
